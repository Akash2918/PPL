import time
print(123)
print(234)
print(789)

time.sleep(5)

print(chr(27) + "[2J")

