print("Enter the matrix A : \n")
rows, cols = (3, 3)
a = [[0] * cols]*rows
a[0][2] = 1
print(a)





