"""def floating(n) :
	x = 1
	for i in n : 
		x = x * i
	print(x)
	s = 0
	m = 0
	for i in n :
		m = x/i	
		print(m)
		s = s + m
	print(s)	
	
m = [1, 2, 3, 6]	
floating(m)		 """
for i in range(1, 10) :
	print(pow(i , 2))



